{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 2,
   "id": "09d85b4b-3c96-4363-92dc-497afeab5e54",
   "metadata": {},
   "outputs": [],
   "source": [
    "# MoodMuse: Emotion-to-Art Generator\n",
    "\n",
    "import gradio as gr"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "id": "dbe24dc0-41e3-4073-84b7-f4b01a4388ec",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "WARNING:tensorflow:From C:\\Users\\Willys PC\\anaconda3\\Lib\\site-packages\\tf_keras\\src\\losses.py:2976: The name tf.losses.sparse_softmax_cross_entropy is deprecated. Please use tf.compat.v1.losses.sparse_softmax_cross_entropy instead.\n",
      "\n",
      "25-04-26 04:37:12 - Directory C:\\Users\\Willys PC\\.deepface has been created\n",
      "25-04-26 04:37:12 - Directory C:\\Users\\Willys PC\\.deepface\\weights has been created\n"
     ]
    }
   ],
   "source": [
    "from deepface import DeepFace"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "id": "9bd77b4b-e9c9-49b0-8281-5f7fb03dff7c",
   "metadata": {},
   "outputs": [],
   "source": [
    "import requests"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 8,
   "id": "8295e8a2-940e-4bba-9075-7ecece27ce35",
   "metadata": {},
   "outputs": [],
   "source": [
    "from PIL import Image"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 10,
   "id": "e8fb8bc7-3c5e-4e5c-8669-009e025f0996",
   "metadata": {},
   "outputs": [],
   "source": [
    "import io"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 12,
   "id": "6b98a9b5-7e9c-4ae1-bcba-0b81f69ff878",
   "metadata": {},
   "outputs": [],
   "source": [
    "# --- Emotion Detection Function ---\n",
    "def detect_emotion(image):\n",
    "    result = DeepFace.analyze(image, actions=['emotion'], enforce_detection=False)\n",
    "    emotion = result[0]['dominant_emotion']\n",
    "    return emotion"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 14,
   "id": "765cfae4-b4ff-4fdf-b013-474d86f8a4bc",
   "metadata": {},
   "outputs": [],
   "source": [
    "# --- Image Generation via Hugging Face API (Stable Diffusion) ---\n",
    "HF_TOKEN = \"your_huggingface_api_token_here\"  # Replace with your token\n",
    "headers = {\n",
    "    \"Authorization\": f\"Bearer {HF_TOKEN}\"\n",
    "}"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 16,
   "id": "e2a2dfd0-a5be-4ba9-bd43-ea871ff73fa2",
   "metadata": {},
   "outputs": [],
   "source": [
    "def generate_image(prompt):\n",
    "    api_url = \"https://api-inference.huggingface.co/models/runwayml/stable-diffusion-v1-5\"\n",
    "    data = {\"inputs\": prompt}\n",
    "    response = requests.post(api_url, headers=headers, json=data)\n",
    "    if response.status_code == 200:\n",
    "        return Image.open(io.BytesIO(response.content))\n",
    "    else:\n",
    "        return None"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 18,
   "id": "db50cdb8-df98-45e9-9067-0fa0168b1042",
   "metadata": {},
   "outputs": [],
   "source": [
    "# --- Main Function ---\n",
    "def moodmuse_pipeline(image):\n",
    "    emotion = detect_emotion(image)\n",
    "    prompt = f\"A surreal painting that represents {emotion}\"\n",
    "    generated_img = generate_image(prompt)\n",
    "    return emotion, generated_img"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 20,
   "id": "f7723879-6444-412e-9fb6-a2fac9ffa5c5",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "* Running on local URL:  http://127.0.0.1:7860\n",
      "\n",
      "To create a public link, set `share=True` in `launch()`.\n"
     ]
    },
    {
     "data": {
      "text/html": [
       "<div><iframe src=\"http://127.0.0.1:7860/\" width=\"100%\" height=\"500\" allow=\"autoplay; camera; microphone; clipboard-read; clipboard-write;\" frameborder=\"0\" allowfullscreen></iframe></div>"
      ],
      "text/plain": [
       "<IPython.core.display.HTML object>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "# --- Gradio UI ---\n",
    "with gr.Blocks() as demo:\n",
    "    gr.Markdown(\"## 🎭 MoodMuse: Emotion-to-Art Generator\")\n",
    "    with gr.Row():\n",
    "        input_img = gr.Image(type=\"pil\", label=\"Upload a selfie\")\n",
    "        output_emotion = gr.Textbox(label=\"Detected Emotion\")\n",
    "    output_img = gr.Image(label=\"Generated Artwork\")\n",
    "    generate_btn = gr.Button(\"Generate Art\")\n",
    "\n",
    "    generate_btn.click(fn=moodmuse_pipeline, inputs=input_img, outputs=[output_emotion, output_img])\n",
    "\n",
    "if __name__ == \"__main__\":\n",
    "    demo.launch()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "696d025b-aa13-4cc0-b775-144219d05f17",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python [conda env:base] *",
   "language": "python",
   "name": "conda-base-py"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.12.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
