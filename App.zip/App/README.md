{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "e59c560b-8b04-4920-856d-a99828fc9efc",
   "metadata": {},
   "outputs": [],
   "source": [
    "# MoodMuse 🎭🖼️\n",
    "\n",
    "**MoodMuse** is an AI-powered web app that generates personalized artwork based on your emotions. Upload a selfie, and the app detects your mood using facial recognition, then generates a surreal painting to match that mood.\n",
    "\n",
    "## 🚀 Demo\n",
    "(Hosted Link, if deploying to Hugging Face Spaces)\n",
    "\n",
    "## ✨ Features\n",
    "- Detects facial emotions using `DeepFace`\n",
    "- Generates images with `Stable Diffusion` via Hugging Face API\n",
    "- Interactive UI powered by `Gradio`\n",
    "\n",
    "## 🧠 AI Tools Used\n",
    "1. **DeepFace** – for facial emotion recognition\n",
    "2. **Stable Diffusion (via Hugging Face)** – for generating AI art\n",
    "\n",
    "## 🛠️ How to Run\n",
    "\n",
    "### Clone the repo\n",
    "```bash\n",
    "git clone https://github.com/your-username/moodmuse.git\n",
    "cd moodmuse\n"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python [conda env:base] *",
   "language": "python",
   "name": "conda-base-py"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.12.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
